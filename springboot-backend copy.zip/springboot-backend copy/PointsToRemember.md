# Points to Remember

#### 1. Customer Record can only be deleted from the table after they have cancelled all their reservations.

#### 2. If a Flight Record is being deleted, then all the reservation status' will be marked as "FLIGHT CANCELLED", otherwise "SCHEDULED".

#### 3. If a Reservation Record is being deleted, then that reserved flight seat will be required to made available again for reservation. 